using System.Text;
using System.Xml.Serialization;
using Microsoft.AspNetCore.Mvc;   // <-- siempre se usaba en clases


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.

app.UseSwagger();
app.UseSwaggerUI();

app.UseHttpsRedirection();

var list = new List<object>();
var random = new Random();

// Funciones auxiliares
static IResult Error(string message)
    => Results.Json(new { error = message }, statusCode: StatusCodes.Status400BadRequest);

static IResult ToXml<T>(T data)
{
    var ns = new XmlSerializerNamespaces();
    ns.Add(string.Empty, string.Empty);
    var serializer = new XmlSerializer(typeof(T));
    using var ms = new MemoryStream();
    serializer.Serialize(ms, data, ns);
    var xml = Encoding.Unicode.GetString(ms.ToArray()); // UTF-16
    return Results.Text(xml, "application/xml; charset=utf-16");
}

app.MapGet("/", () => Results.Redirect("/swagger"));

app.MapPost("/", () => list);

app.MapPut("/", ([FromForm] int quantity, [FromForm] string type) =>
{
    var random = new Random();
    if (type == "int")
    {
        for (; quantity > 0; quantity--)
        {
            list.Add(random.Next());
        }
    }
    else if (type == "float")
    {
        for (; quantity > 0; quantity--)
        {
            list.Add(random.NextSingle());
        }
    }
}).DisableAntiforgery();

app.MapDelete("/", ([FromForm] int quantity) =>
{
    for (; quantity > 0; quantity--)
    {
        list.RemoveAt(0);
    }
}).DisableAntiforgery();

app.MapPatch("/", () =>
{
    return Results.Ok();
});

// PATCH: limpia completamente la lista
app.MapPatch("/", () =>
{
    list.Clear();
    return Results.Json(list);
}).WithSummary("Limpia completamente la lista");

app.Run();
