using Microsoft.AspNetCore.Mvc;
using MVC.Models;
using System.Linq; // Necesario para usar LINQ

namespace MVC.Controllers;

public class HomeController : Controller
{
    [HttpGet]
    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Index(TheModel model)
    {
        ViewBag.Valid = ModelState.IsValid;

        if (ViewBag.Valid)
        {
            // Filtramos los caracteres eliminando los espacios
            var charArray = model.Phrase!
                .Where(c => !char.IsWhiteSpace(c))  // 🔹 elimina espacios
                .ToList();

            foreach (var c in charArray)
            {
                if (!model.Counts!.ContainsKey(c))
                {
                    model.Counts[c] = 0;
                }
                model.Counts[c]++;
                model.Lower += c.ToString().ToLower();
                model.Upper += c.ToString().ToUpper();
            }
        }

        return View(model);
    }
}
